'use strict';

angular.module('myApp.templateInvestigator', ['ngRoute'])

.controller('templateInvestigatorCtrl', ['$rootScope', '$scope', '$location', function ($rootScope, $scope, $location) {

      $scope.continueLogoutI=function(){
            $location.path("view1");
      };
      $scope.continueHomeI=function(){
            $location.path("HomeInvestigator");
      };
      $scope.continueRegistersI=function(){
            //$location.path("RegistersInvestigatorView");
      };
}]);
